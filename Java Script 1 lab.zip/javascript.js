  //last char returning
console.log('  //last char returning')
var result = '';
function getLast(line) {
  var indexoflast = line.length;
  var result = line[indexoflast - 1];
  return result;
}

var last = getLast('retard');
console.log('Last char in your line is: ', last);

  //last char deleting
console.log('  //last char deleting')
function deleteLast(line) {
  var indexoflast = line.length;
  for(var a = 0; a < indexoflast - 1; a++) {
    result = result + line[a]; 
  }
}

deleteLast('retard');
console.log('Your line without last char: ', result);

  //reversing line
console.log('  //reversing line')
function lineReverse(line) { 
  line = line.split("").reverse().join("");
  console.log('Your line in reverse: ', line);
} 

lineReverse('retard');

  //space killer
console.log('  //space killer')
function spaceKiller(line) {  
  var result = line.replace(/\s+/g, " "); 
  console.log('There is a result of our work: ', result, ' ,but not now'); 
} 
spaceKiller(' Hello, my name     is Daniil and      I am    scared of    gapes');